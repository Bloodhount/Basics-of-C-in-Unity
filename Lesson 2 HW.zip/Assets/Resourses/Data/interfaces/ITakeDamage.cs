using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public interface ITakeDamage //: MonoBehaviour
{
    public void TakeDamage(int damageValue);
}
