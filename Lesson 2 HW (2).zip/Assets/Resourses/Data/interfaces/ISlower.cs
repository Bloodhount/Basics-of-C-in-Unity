

public interface ISlower
{
    public void Slower();
}
