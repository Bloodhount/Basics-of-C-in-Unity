
public interface ITakeDamage 
{
    public void TakeDamage(int damageValue);
}
