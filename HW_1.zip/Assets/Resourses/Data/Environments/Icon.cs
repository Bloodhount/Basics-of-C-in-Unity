using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Icon : MonoBehaviour
{
    //[SerializeField] private Transform _transformTarget;
    //[SerializeField] private Text _distToTargetText;
    //private CoinsManager _coinsManager;

    void Start()
    {
        //_distToTargetText.text = _coinsManager.DistanceToCoin.ToString();
        //_transformTarget = GetComponent<Transform>();
    }

    void Update()
    {
        //Vector3 toTarget = _transformTarget.position - transform.position;
       // Vector3 toTargetXZ = new Vector3(toTarget.x, 0f, toTarget.z);
       // transform.rotation = Quaternion.LookRotation(toTargetXZ);
        //_distToTargetText = toTarget.ToString();
        //_distToTargetText.text = _coinsManager.DistanceToCoin.ToString();

    }
}
